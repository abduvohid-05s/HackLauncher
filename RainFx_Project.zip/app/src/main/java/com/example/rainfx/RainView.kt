package com.example.rainfx

import android.content.Context
import android.graphics.Canvas
import android.view.View

class RainView(ctx: Context) : View(ctx) {
    private var core: RainCore? = null
    private var running = false

    private val ticker = object : Runnable {
        override fun run() {
            core?.step()
            invalidate()
            if (running) postDelayed(this, 33L)
        }
    }

    fun setCfg(c: Cfg) {
        core = RainCore(c, resources.displayMetrics.density).also { it.resize(width, height) }
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        core?.resize(w, h)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        post(ticker)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(ticker)
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        core?.draw(c, 255)
    }
}

package com.example.rainfx

import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

class RainWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = RainEngine()

    inner class RainEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var core: RainCore? = null
        private var sig = ""
        private var w = 0
        private var h = 0
        private var visible = false

        private val runner = object : Runnable {
            override fun run() {
                draw()
                if (visible) handler.postDelayed(this, 33L)
            }
        }

        private fun load() {
            val s = Prefs.sig(this@RainWallpaperService)
            if (s != sig || core == null) {
                sig = s
                core = RainCore(Prefs.cfg(this@RainWallpaperService), resources.displayMetrics.density)
                    .also { it.resize(w, h) }
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            w = width
            h = height
            load()
            core?.resize(w, h)
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            handler.removeCallbacks(runner)
            if (v) {
                load()
                handler.post(runner)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(runner)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            handler.removeCallbacks(runner)
            core = null
            super.onDestroy()
        }

        private fun draw() {
            val cc = core ?: return
            cc.step()
            var canvas: Canvas? = null
            try {
                canvas = surfaceHolder.lockCanvas()
                if (canvas != null) cc.draw(canvas, 200)
            } finally {
                if (canvas != null) surfaceHolder.unlockCanvasAndPost(canvas)
            }
        }
    }
}

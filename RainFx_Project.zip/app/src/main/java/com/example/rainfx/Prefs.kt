package com.example.rainfx

import android.content.Context
import android.graphics.Color

class Cfg(
    val mode: Int,
    val bg: Int,
    val tail: Int,
    val head: Int,
    val textDp: Float,
    val chars: CharArray,
    val words: List<String>
)

object Prefs {
    val modes = listOf(
        "Klassik oqim" to "yorqin bosh harf va xiralashuvchi iz",
        "Yakka harflar" to "izsiz, har bir harf alohida to'g'ri tushadi",
        "So'zlar" to "so'zlar yuqoridan pastga yoziladi",
        "Chuqurlik" to "3 qatlam: katta-tez va kichik-sekin harflar",
        "Miltillovchi" to "tushayotganda harflar o'zgarib turadi",
        "To'planish" to "harflar pastda to'planib boradi"
    )
    val colors = listOf(
        "Yashil" to 0xFF00FF41.toInt(),
        "Qizil" to 0xFFFF1744.toInt(),
        "Siyan (ko'k muz)" to 0xFF00E5FF.toInt(),
        "Binafsha" to 0xFFB388FF.toInt(),
        "Amber (sariq)" to 0xFFFFB300.toInt(),
        "Pushti neon" to 0xFFFF4FD8.toInt(),
        "Oq" to 0xFFE8E8E8.toInt(),
        "Tungi yashil (xira)" to 0xFF00A82D.toInt()
    )
    val sets = listOf(
        "Binar (0, 1)" to "01",
        "Raqamlar (0-9)" to "0123456789",
        "Lotin kichik harflar" to "abcdefghijklmnopqrstuvwxyz",
        "Lotin katta harflar" to "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
        "Kod belgilari" to "{}[]();=<>&|!+-*/_#\$%@",
        "Hex (A-F)" to "ABCDEF",
        "Kirill harflari" to "АБВГДЕЖЗИКЛМНОПРСТУФХЦЧШЭЮЯ"
    )
    private val defaultWords = listOf(
        "root", "sudo", "hack", "ssh", "kali", "shell", "admin", "0day", "nmap", "token", "cipher", "exploit"
    )

    private fun p(c: Context) = c.getSharedPreferences("rainfx", Context.MODE_PRIVATE)

    fun mode(c: Context) = p(c).getInt("mode", 0).coerceIn(0, modes.size - 1)
    fun setMode(c: Context, v: Int) { p(c).edit().putInt("mode", v).apply() }
    fun color(c: Context) = p(c).getInt("color", 0).coerceIn(0, colors.size - 1)
    fun setColor(c: Context, v: Int) { p(c).edit().putInt("color", v).apply() }
    fun size(c: Context) = p(c).getInt("size", 35).coerceIn(0, 100)
    fun setSize(c: Context, v: Int) { p(c).edit().putInt("size", v).apply() }
    fun mask(c: Context) = p(c).getInt("mask", 22)
    fun setMask(c: Context, v: Int) { p(c).edit().putInt("mask", v).apply() }
    fun custom(c: Context): String = p(c).getString("custom", "") ?: ""
    fun setCustom(c: Context, v: String) { p(c).edit().putString("custom", v).apply() }
    fun setupDone(c: Context) = p(c).getBoolean("setup", false)
    fun setSetupDone(c: Context) { p(c).edit().putBoolean("setup", true).apply() }

    fun pool(c: Context): String {
        val sb = StringBuilder()
        sets.forEachIndexed { i, s -> if ((mask(c) and (1 shl i)) != 0) sb.append(s.second) }
        sb.append(custom(c).filter { !it.isWhitespace() && !Character.isSurrogate(it) })
        val out = sb.toString().toSet().joinToString("")
        return if (out.isEmpty()) "01" else out
    }

    fun sig(c: Context) = "${mode(c)}|${color(c)}|${size(c)}|${mask(c)}|${custom(c)}"

    fun cfg(c: Context): Cfg {
        val tail = colors[color(c)].second
        val r = Color.red(tail)
        val g = Color.green(tail)
        val b = Color.blue(tail)
        val bg = Color.rgb((r * 0.04f).toInt() + 3, (g * 0.04f).toInt() + 3, (b * 0.04f).toInt() + 3)
        val head = Color.rgb(
            r + ((255 - r) * 0.8f).toInt(),
            g + ((255 - g) * 0.8f).toInt(),
            b + ((255 - b) * 0.8f).toInt()
        )
        val extra = custom(c).split(Regex("\\s+"))
            .filter { w -> w.length >= 2 && w.none { Character.isSurrogate(it) } }
        return Cfg(mode(c), bg, tail, head, 10f + 38f * size(c) / 100f, pool(c).toCharArray(), defaultWords + extra)
    }
}

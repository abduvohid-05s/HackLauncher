package com.example.rainfx

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {
    private val green = Color.parseColor("#00FF41")
    private val dim = Color.parseColor("#00B82E")
    private val black = Color.parseColor("#050805")
    private val mp = ViewGroup.LayoutParams.MATCH_PARENT
    private val wc = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var holder: LinearLayout
    private var page = "hub"
    private var statusView: TextView? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sv = ScrollView(this)
        sv.setBackgroundColor(black)
        holder = LinearLayout(this)
        holder.orientation = LinearLayout.VERTICAL
        holder.setPadding(dp(16), dp(40), dp(16), dp(24))
        sv.addView(holder)
        setContentView(sv)
        if (Prefs.setupDone(this)) showHub() else showSetup()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val locked = page == "setup" && !Prefs.setupDone(this)
        if (page != "hub" && !locked) showHub() else super.onBackPressed()
    }

    // ---------- yordamchilar ----------
    private fun begin(name: String) {
        holder.removeAllViews()
        statusView = null
        page = name
    }

    private fun tv(t: String, size: Float = 14f, color: Int = green, pad: Int = 0): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.typeface = Typeface.MONOSPACE
        v.setTextColor(color)
        v.setPadding(0, dp(pad), 0, dp(pad))
        return v
    }

    private fun btn(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.typeface = Typeface.MONOSPACE
        b.setOnClickListener { onClick() }
        return b
    }

    private fun header(title: String, back: Boolean) {
        if (back) holder.addView(btn("← Orqaga") { showHub() })
        holder.addView(tv("> $title", 20f, green, 8))
    }

    private fun preview(hDp: Int): RainView {
        val rv = RainView(this)
        rv.setCfg(Prefs.cfg(this))
        holder.addView(rv, LinearLayout.LayoutParams(mp, dp(hDp)))
        return rv
    }

    private fun row(title: String, value: String, go: () -> Unit) {
        holder.addView(btn("$title  ›  $value", go))
    }

    // ---------- sahifalar ----------
    private fun showSetup() {
        begin("setup")
        header("ruxsatlar", Prefs.setupDone(this))
        holder.addView(tv("Bu ilova xavfli ruxsat so'ramaydi: kamera, joylashuv, xotira va kontaktlar KERAK EMAS.", 14f, green, 8))
        holder.addView(tv("Kerakli yagona ruxsat: jonli fonni o'rnatishni tasdiqlash. Buni Android o'zi so'raydi.", 14f, green, 8))
        val st = tv("", 16f, green, 12)
        statusView = st
        holder.addView(st)
        holder.addView(btn("Jonli fonni o'rnatish (ruxsat berish)") { applyWallpaper() })
        holder.addView(btn("Davom etish") {
            Prefs.setSetupDone(this)
            showHub()
        })
        updateStatus()
    }

    private fun showHub() {
        begin("hub")
        header("yomgir_fon", false)
        preview(180)
        row("Animatsiya variantlari", Prefs.modes[Prefs.mode(this)].first) { showModes() }
        row("Animatsiya ranglari", Prefs.colors[Prefs.color(this)].first) { showColors() }
        row("Yozuv hajmi", "${Prefs.size(this)}%") { showSize() }
        row("Belgilar", "${Prefs.pool(this).length} ta") { showSymbols() }
        row("Ruxsatlar", "holatni ko'rish") { showSetup() }
        holder.addView(btn("Jonli fonni o'rnatish") { applyWallpaper() })
    }

    private fun showModes() {
        begin("modes")
        header("animatsiya_variantlari", true)
        val rv = preview(160)
        val cur = Prefs.mode(this)
        val g = RadioGroup(this)
        Prefs.modes.forEachIndexed { i, m ->
            val rb = RadioButton(this)
            rb.id = 2000 + i
            rb.text = m.first + "\n" + m.second
            rb.typeface = Typeface.MONOSPACE
            rb.setTextColor(green)
            rb.isChecked = i == cur
            g.addView(rb)
        }
        g.setOnCheckedChangeListener { _, cid ->
            Prefs.setMode(this, cid - 2000)
            rv.setCfg(Prefs.cfg(this))
        }
        holder.addView(g)
    }

    private fun showColors() {
        begin("colors")
        header("animatsiya_ranglari", true)
        val rv = preview(160)
        val cur = Prefs.color(this)
        val g = RadioGroup(this)
        Prefs.colors.forEachIndexed { i, cl ->
            val rb = RadioButton(this)
            rb.id = 3000 + i
            rb.text = cl.first
            rb.typeface = Typeface.MONOSPACE
            rb.setTextColor(cl.second)
            rb.isChecked = i == cur
            g.addView(rb)
        }
        g.setOnCheckedChangeListener { _, cid ->
            Prefs.setColor(this, cid - 3000)
            rv.setCfg(Prefs.cfg(this))
        }
        holder.addView(g)
    }

    private fun showSize() {
        begin("size")
        header("yozuv_hajmi", true)
        val rv = preview(200)
        val label = tv("Hajm: ${Prefs.size(this)}%", 16f, green, 12)
        val bar = SeekBar(this)
        bar.max = 100
        bar.progress = Prefs.size(this)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                Prefs.setSize(this@MainActivity, p)
                label.text = "Hajm: $p%"
                if (fromUser) rv.setCfg(Prefs.cfg(this@MainActivity))
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val line = LinearLayout(this)
        line.orientation = LinearLayout.HORIZONTAL
        line.gravity = Gravity.CENTER_VERTICAL
        line.addView(tv("0%"))
        line.addView(bar, LinearLayout.LayoutParams(0, wc, 1f))
        line.addView(tv("100%"))
        holder.addView(line)
        holder.addView(label)
    }

    private fun showSymbols() {
        begin("symbols")
        header("belgilar", true)
        val rv = preview(160)
        val count = tv("", 14f, dim, 8)

        fun refresh() {
            count.text = "Jami belgilar: ${Prefs.pool(this).length}"
            rv.setCfg(Prefs.cfg(this))
        }

        holder.addView(count)
        Prefs.sets.forEachIndexed { i, s ->
            val cb = CheckBox(this)
            cb.text = s.first + "   " + s.second.take(12)
            cb.typeface = Typeface.MONOSPACE
            cb.setTextColor(green)
            cb.isChecked = (Prefs.mask(this) and (1 shl i)) != 0
            cb.setOnCheckedChangeListener { _, on ->
                val m = Prefs.mask(this)
                Prefs.setMask(this, if (on) m or (1 shl i) else m and (1 shl i).inv())
                refresh()
            }
            holder.addView(cb)
        }
        holder.addView(tv("O'z belgilaringiz. Bo'sh joy bilan ajratilgan so'zlar \"So'zlar\" variantiga ham qo'shiladi:", 13f, green, 8))
        val et = EditText(this)
        et.setText(Prefs.custom(this))
        et.setTextColor(green)
        et.setHintTextColor(dim)
        et.hint = "masalan: @#% ROOT hack"
        et.typeface = Typeface.MONOSPACE
        holder.addView(et)
        holder.addView(btn("Qo'shish / saqlash") {
            Prefs.setCustom(this, et.text.toString())
            refresh()
        })
        holder.addView(btn("Tozalash") {
            et.setText("")
            Prefs.setCustom(this, "")
            refresh()
        })
        refresh()
    }

    // ---------- jonli fon ----------
    private fun isActive(): Boolean = try {
        WallpaperManager.getInstance(this).wallpaperInfo?.packageName == packageName
    } catch (e: Exception) {
        false
    }

    private fun updateStatus() {
        statusView?.text = if (isActive()) "✓ Jonli fon faol" else "✗ Jonli fon hali o'rnatilmagan"
    }

    private fun applyWallpaper() {
        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
        i.putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, RainWallpaperService::class.java)
        )
        try {
            startActivity(i)
        } catch (e: Exception) {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }
}

package com.example.rainfx

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import kotlin.math.pow
import kotlin.random.Random

class RainCore(private val c: Cfg, private val density: Float) {
    private val paint = Paint().apply {
        typeface = Typeface.MONOSPACE
        isAntiAlias = true
    }
    private val one = CharArray(1)
    private val rnd = Random
    private val fs = c.textDp * density
    private val cw = fs * 0.8f
    private val sp = 0.18f
    private val zs = floatArrayOf(0.6f, 0.95f, 1.45f)
    private val al = floatArrayOf(0.35f, 0.65f, 1f)
    private val vs = floatArrayOf(0.6f, 1.2f, 2.4f)

    private class P {
        var x = 0f
        var y = 0f
        var v = 0f
        var ch = '0'
        var cells = CharArray(0)
        var len = 0
        var word = ""
        var layer = 0
        var bright = false
    }

    private var w = 0
    private var h = 0
    private var ps: Array<P> = emptyArray()
    private var piles: Array<ArrayList<Char>> = emptyArray()

    private fun rc(): Char = c.chars[rnd.nextInt(c.chars.size)]
    private fun rw(): String = c.words[rnd.nextInt(c.words.size)]
    private fun cols() = (w / cw).toInt() + 1

    private fun stream(first: Boolean): P {
        val p = P()
        p.len = 8 + rnd.nextInt(9)
        p.cells = CharArray(p.len) { rc() }
        p.y = if (first) -rnd.nextFloat() * 40f else -rnd.nextFloat() * 6f
        p.v = sp * (0.6f + rnd.nextFloat() * 0.8f)
        return p
    }

    fun resize(width: Int, height: Int) {
        if (width <= 0 || height <= 0) return
        w = width
        h = height
        val n = cols()
        when (c.mode) {
            0, 4 -> ps = Array(n) { stream(true) }
            1 -> ps = Array(n * 2) {
                P().also { p ->
                    p.x = rnd.nextInt(n) * cw
                    p.y = -rnd.nextFloat() * h
                    p.v = fs * sp * (0.7f + rnd.nextFloat() * 0.8f)
                    p.ch = rc()
                    p.bright = rnd.nextFloat() < 0.15f
                }
            }
            2 -> ps = Array((n + 1) / 2) { i ->
                P().also { p ->
                    p.x = i * 2 * cw
                    p.word = rw()
                    p.y = -rnd.nextFloat() * h * 2f
                    p.v = fs * sp * (0.6f + rnd.nextFloat() * 0.8f)
                }
            }
            3 -> ps = Array(70) { i ->
                P().also { p ->
                    p.x = rnd.nextFloat() * w
                    p.y = rnd.nextFloat() * h
                    p.layer = i % 3
                    p.ch = rc()
                }
            }
            else -> {
                ps = Array(n) {
                    P().also { p ->
                        p.y = -rnd.nextFloat() * h * 0.8f
                        p.ch = rc()
                        p.v = fs * sp * (1.8f + rnd.nextFloat() * 0.8f)
                    }
                }
                piles = Array(n) { ArrayList<Char>() }
            }
        }
    }

    fun step() {
        when (c.mode) {
            0, 4 -> for (i in ps.indices) {
                val p = ps[i]
                val o = p.y.toInt()
                p.y += p.v
                if (p.y.toInt() != o) {
                    System.arraycopy(p.cells, 0, p.cells, 1, p.len - 1)
                    p.cells[0] = rc()
                }
                if (c.mode == 4) {
                    for (j in 0 until p.len) if (rnd.nextFloat() < 0.08f) p.cells[j] = rc()
                }
                if ((p.y - p.len) * fs > h) ps[i] = stream(false)
            }
            1 -> for (p in ps) {
                p.y += p.v
                if (p.y > h + fs) {
                    p.y = -fs
                    p.x = rnd.nextInt(cols()) * cw
                    p.ch = rc()
                    p.bright = rnd.nextFloat() < 0.15f
                }
            }
            2 -> for (p in ps) {
                p.y += p.v
                if (p.y > h + fs) {
                    p.word = rw()
                    p.y = -p.word.length * fs - rnd.nextFloat() * h * 0.5f
                }
            }
            3 -> for (p in ps) {
                p.y += vs[p.layer] * density
                if (rnd.nextFloat() < 0.02f) p.ch = rc()
                if (p.y > h + 30f * density) {
                    p.y = -30f * density
                    p.x = rnd.nextFloat() * w
                    p.ch = rc()
                }
            }
            else -> {
                var mx = 0
                for (i in ps.indices) {
                    val p = ps[i]
                    val pl = piles[i]
                    p.y += p.v
                    if (p.y >= h - pl.size * fs - 3f) {
                        pl.add(p.ch)
                        p.y = -fs - rnd.nextFloat() * h * 0.2f
                        p.ch = rc()
                    }
                    if (pl.size > mx) mx = pl.size
                }
                if (mx > (h / fs) * 0.3f) for (pl in piles) pl.clear()
            }
        }
    }

    private fun put(col: Int, a: Float) {
        paint.color = col
        paint.alpha = a.toInt().coerceIn(0, 255)
    }

    private fun ch(t: Canvas, ch: Char, x: Float, y: Float) {
        one[0] = ch
        t.drawText(one, 0, 1, x, y, paint)
    }

    fun draw(t: Canvas, alpha: Int) {
        t.drawColor(c.bg)
        paint.textSize = fs
        when (c.mode) {
            0, 4 -> for (i in ps.indices) {
                val p = ps[i]
                val x = i * cw
                for (k in 0 until p.len) {
                    val y = (p.y - k) * fs
                    if (y < -fs || y > h + fs) continue
                    val f = (1f - k.toFloat() / p.len).pow(1.3f)
                    put(if (k == 0) c.head else c.tail, alpha * f)
                    t.drawText(p.cells, k, 1, x, y, paint)
                }
            }
            1 -> for (p in ps) {
                put(if (p.bright) c.head else c.tail, alpha * (if (p.bright) 1f else 0.75f))
                ch(t, p.ch, p.x, p.y)
            }
            2 -> for (p in ps) {
                val wd = p.word
                for (j in wd.indices) {
                    val y = p.y + j * fs
                    if (y < -fs || y > h + fs) continue
                    val last = j == wd.length - 1
                    put(if (last) c.head else c.tail, alpha * (if (last) 1f else 0.85f))
                    ch(t, wd[j], p.x, y)
                }
            }
            3 -> for (p in ps) {
                paint.textSize = fs * zs[p.layer]
                put(if (p.layer == 2) c.head else c.tail, alpha * al[p.layer])
                ch(t, p.ch, p.x, p.y)
            }
            else -> for (i in ps.indices) {
                val p = ps[i]
                val x = i * cw
                put(c.head, alpha.toFloat())
                ch(t, p.ch, x, p.y)
                put(c.tail, alpha * 0.6f)
                val pl = piles[i]
                for (j in pl.indices) ch(t, pl[j], x, h - j * fs - 3f)
            }
        }
    }
}
